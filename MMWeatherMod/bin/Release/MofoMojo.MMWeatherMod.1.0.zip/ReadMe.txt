﻿MofoMojo's Prayers for Rain Mod
This mod is a simple mod that allows you to pray for clear weather. 

When outside, with the sky above you
	Have a seat and pray
When the fog's against you and your ships' crew
	Have a seat and pray

:: USE ::
Open the chat window and issue 
/pray

or ... 

:: REQUIREMENTS ::
• BepInEx - 

:: INSTALLATION ::
Place the MMWishboneTweak.dll in your \BepinEx\Plugins folder
Start Valheim Once and then exit. 
Modify the \BepInEx\Config\MofoMojo.MMWeatherMod.cfg as you see fit.
Play Valheim

:: UNINSTALLATION ::
Remove the .DLL and the .CFG file from the \Plugins and \Config folders respectively.

:: FEATURES ::
• You can pray for other weather such as rain, thunderstorm, lightrain, snow, and others that i'll leave up to you to find.
• Uses Localization strings built into the game for hints...

::  KNOWN ISSUES ::
• You must be outside
• You must be seated or sitting or in a boat
• You can't always get what you want...

::  CREDITS Template::
♦ https://www.youtube.com/watch?v=p_gsFASlvRw
♦ https://harmony.pardeike.net/ - Harmony Documentation
♦ https://github.com/Valheim-Modding/Wiki/wiki - Valheim modding
