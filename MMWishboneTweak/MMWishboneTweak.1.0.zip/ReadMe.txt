﻿MofoMojo's Wishbone Tweaks
This mod adds the ability for the wishbone to find Copper and Tin ores

:: REQUIREMENTS ::
• BepinEx - 

:: INSTALLATION ::
Place the MMWishboneTweak.dll in your \BepinEx\Plugins folder
Start Valheim Once and then exit. 
Modify the \BepinEx\Config\MofoMojo.MMWishboneTweak.cfg file to enable the mod.
Play Valheim

:: UNINSTALLATION ::
Remove the .DLL and the .CFG file from the \Plugins and \Config folders respectively.

:: FEATURES ::
• Adds beacons to Copper and Tin so that the Wishbone will find them
• Tin range is increased from default 20 to 25
• Copper range is increased from default 20 to 60 (otherwise you're literally on top of the copper almost before it pings)


::  KNOWN ISSUES ::
• None

::  CREDITS Template::
♦ https://www.youtube.com/watch?v=p_gsFASlvRw
♦ https://harmony.pardeike.net/ - Harmony Documentation
♦ https://github.com/Valheim-Modding/Wiki/wiki - Valheim modding